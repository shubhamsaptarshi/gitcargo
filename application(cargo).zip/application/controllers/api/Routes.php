<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Routes extends CI_Controller {
public function __construct() {
        parent::__construct();
    }
  /**
   * Index Page for this controller.
   */
public function index() {
     
  }


}