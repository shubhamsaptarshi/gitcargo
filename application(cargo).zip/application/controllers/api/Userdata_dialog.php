<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Userdata_dialog extends CI_Controller{
public function __construct(){
    parent::__construct();
}
public function index(){

}
public function method1(){}
}