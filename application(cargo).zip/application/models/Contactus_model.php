<?php
class Contactus_model extends CI_Model{

}