<?php

defined('BASEPATH') OR exit('No direct script access allowed');

$config['googleplus']['application_name'] = 't2s';
// $config['googleplus']['client_id']        = '389351980770-pv8925o66s2096qsptal9sl5f7si0jal.apps.googleusercontent.com';
$config['googleplus']['client_id']        = '946831252927-5tf2qdi07mnb34b3lr6u649n7addkola.apps.googleusercontent.com';
// $config['googleplus']['client_secret']    = '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';
$config['googleplus']['client_secret']    = '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';
$config['googleplus']['redirect_uri']     = 'http://localhost/t2s/Login/glogin';
// $config['googleplus']['api_key']          = 'AIzaSyB0fJ0RX424iP5Zc_aOoZNAOmpt6Qhd_dU';
$config['googleplus']['api_key']          = 'AIzaSyDPIGncB9ZVTMjVFsvwkp65qWJIvT8VuK8';
$config['googleplus']['scopes']           = array();

